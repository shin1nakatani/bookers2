# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '9f9c7d1ca3e1ea38d988ba2f0edfc1b982229dcc78d0fb43cefea306a8170e4902249f3de9979d368b8dde1c7f9a0f2a2023b8a0de73c7345a2ee4c55a28c81b'