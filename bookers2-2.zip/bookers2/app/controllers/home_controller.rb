class HomeController < ApplicationController

  def about
  end

end
