class HomesController < ApplicationController

  def about
  end

end
