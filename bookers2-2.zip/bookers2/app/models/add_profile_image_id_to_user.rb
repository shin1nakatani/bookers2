class AddProfileImageIdToUser < ApplicationRecord
end
